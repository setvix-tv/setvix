package tv.setvix.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Самообновление приложения: скачивает новый APK и передаёт его системному установщику. */
final class Updater {
    private Updater() {}

    static void install(final MainActivity act, final String apkUrl) {
        new Thread(() -> {
            try {
                act.runOnUiThread(() -> act.sendEvent("update", "{\"s\":\"downloading\"}"));
                HttpURLConnection c = null;
                String u = apkUrl;
                for (int hop = 0; hop < 6; hop++) {
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(60000);
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        if (loc == null) throw new Exception("redirect without location");
                        u = new URL(new URL(u), loc).toString();
                        continue;
                    }
                    if (code != 200) throw new Exception("HTTP " + code);
                    break;
                }
                PackageInstaller pi = act.getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                int id = pi.createSession(params);
                PackageInstaller.Session session = pi.openSession(id);
                try (InputStream in = c.getInputStream(); OutputStream out = session.openWrite("setvix", 0, -1)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    session.fsync(out);
                }
                Intent cb = new Intent(act, MainActivity.class).setAction(MainActivity.INSTALL_ACTION);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
                PendingIntent p = PendingIntent.getActivity(act, id, cb, flags);
                session.commit(p.getIntentSender());
                session.close();
                act.runOnUiThread(() -> act.sendEvent("update", "{\"s\":\"installing\"}"));
            } catch (Exception e) {
                final String m = String.valueOf(e.getMessage());
                act.runOnUiThread(() -> act.sendEvent("update", "{\"s\":\"failed\",\"m\":" + MainActivity.q(m) + "}"));
            }
        }).start();
    }
}
