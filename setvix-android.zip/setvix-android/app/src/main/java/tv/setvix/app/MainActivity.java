package tv.setvix.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * Setvix для Android TV.
 * Интерфейс — веб-страница (обновляется сама с сайта), видео — нативный движок ExoPlayer под ней.
 */
public class MainActivity extends Activity {
    static final String INSTALL_ACTION = "tv.setvix.app.INSTALL_STATUS";

    private WebView web;
    private NativePlayer player;
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0C1424);

        SurfaceView surface = new SurfaceView(this);
        surface.setFocusable(false);
        surface.setVisibility(View.GONE);
        root.addView(surface, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        player = new NativePlayer(this, root, surface);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(this, player), "SetvixNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return LocalServer.handle(MainActivity.this, request);
            }
        });
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        web.loadUrl(LocalServer.BASE + "index.html");
        hideSystemUi();
    }

    /** Отправить событие в интерфейс. Вызывать только из главного потока. */
    void sendEvent(String type, String jsonData) {
        if (web == null) return;
        String js = "window.svNative&&svNative.onEvent({\"t\":\"" + type + "\",\"d\":" + (jsonData == null ? "null" : jsonData) + "})";
        web.evaluateJavascript(js, null);
    }

    static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 0x20) b.append(' ');
            else b.append(c);
        }
        return b.append('"').toString();
    }

    /** Строка в формате JSON со всеми экранированиями (для больших ответов сервера). */
    static String jsonString(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder(s.length() + 16).append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '\u2028': b.append("\\u2028"); break;
                case '\u2029': b.append("\\u2029"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        String name = null;
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) name = "back";
        else if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_SETTINGS) name = "menu";
        else if (code == KeyEvent.KEYCODE_CHANNEL_UP) name = "chup";
        else if (code == KeyEvent.KEYCODE_CHANNEL_DOWN) name = "chdown";
        else if (code == KeyEvent.KEYCODE_GUIDE) name = "guide";
        else if (code == KeyEvent.KEYCODE_INFO) name = "info";
        else if (code == KeyEvent.KEYCODE_LAST_CHANNEL) name = "last";
        else if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY || code == KeyEvent.KEYCODE_MEDIA_PAUSE) name = "playpause";
        if (name != null) {
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("window.svKey&&svKey('" + name + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && INSTALL_ACTION.equals(intent.getAction())) {
            int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
            if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(confirm); } catch (Exception ignored) { }
                }
            } else if (status != PackageInstaller.STATUS_SUCCESS) {
                sendEvent("update", "{\"s\":\"failed\",\"m\":" + q(intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)) + "}");
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Setvix leaves the screen: stop the stream, tell the page, and freeze its timers so nothing can start in the background
        player.stop();
        web.evaluateJavascript("window.svBg&&svBg(true)", null);
        web.onPause();
        web.pauseTimers();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.resumeTimers();
        web.onResume();
        hideSystemUi();
        player.resume();
        web.evaluateJavascript("window.svBg&&svBg(false);window.svCheckUpdate&&svCheckUpdate()", null);
    }

    @Override
    protected void onDestroy() {
        player.release();
        web.destroy();
        super.onDestroy();
    }
}
