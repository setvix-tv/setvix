package tv.setvix.app;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Локальный «сервер» внутри приложения:
 *  https://setvix.local/index.html  -> плеер из assets
 *  https://setvix.local/proxy?url=  -> загрузка любого адреса без ограничений CORS и http/https
 */
final class LocalServer {
    static final String HOST = "setvix.local";
    static final String BASE = "https://" + HOST + "/";
    private static final String UA = "Mozilla/5.0 (Linux; Android 10; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36 SetvixTV/1.0";

    private LocalServer() {}

    static WebResourceResponse handle(Context ctx, WebResourceRequest req) {
        Uri uri = req.getUrl();
        if (!HOST.equals(uri.getHost())) return null; // остальное идёт в сеть как обычно
        String path = uri.getPath() == null ? "/" : uri.getPath();
        try {
            if (path.equals("/") || path.equals("/index.html")) {
                InputStream in = ctx.getAssets().open("index.html");
                return response(200, "OK", "text/html", "utf-8", in, null);
            }
            if (path.equals("/proxy")) {
                String target = uri.getQueryParameter("url");
                if (target == null || !(target.startsWith("http://") || target.startsWith("https://"))) {
                    return text(400, "Bad Request", "bad url");
                }
                return proxy(target, req.getRequestHeaders());
            }
            return text(404, "Not Found", "not found");
        } catch (Exception e) {
            return text(502, "Bad Gateway", String.valueOf(e.getMessage()));
        }
    }

    private static WebResourceResponse proxy(String target, Map<String, String> reqHeaders) throws Exception {
        HttpURLConnection c = null;
        String url = target;
        for (int hop = 0; hop < 6; hop++) {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(12000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "*/*");
            if (reqHeaders != null) {
                for (Map.Entry<String, String> h : reqHeaders.entrySet()) {
                    if ("range".equalsIgnoreCase(h.getKey())) c.setRequestProperty("Range", h.getValue());
                }
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) return text(502, "Bad Gateway", "redirect without location");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            break;
        }
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) return text(502, "Bad Gateway", "too many redirects");

        String ct = c.getContentType();
        String mime = "application/octet-stream", enc = null;
        if (ct != null) {
            String[] parts = ct.split(";");
            mime = parts[0].trim();
            for (String p : parts) {
                String t = p.trim().toLowerCase();
                if (t.startsWith("charset=")) enc = t.substring(8);
            }
        }
        InputStream body = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (body == null) body = new ByteArrayInputStream(new byte[0]);
        String reason = c.getResponseMessage();
        if (reason == null || reason.trim().isEmpty()) reason = code < 400 ? "OK" : "Error";
        Map<String, String> extra = new HashMap<>();
        String cr = c.getHeaderField("Content-Range");
        if (cr != null) extra.put("Content-Range", cr);
        return response(code, reason, mime, enc, body, extra);
    }

    private static WebResourceResponse text(int code, String reason, String msg) {
        return response(code, reason, "text/plain", "utf-8",
            new ByteArrayInputStream(msg.getBytes(StandardCharsets.UTF_8)), null);
    }

    private static WebResourceResponse response(int code, String reason, String mime, String enc, InputStream in, Map<String, String> extra) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        if (extra != null) h.putAll(extra);
        return new WebResourceResponse(mime, enc, code, reason, h, in);
    }
}
