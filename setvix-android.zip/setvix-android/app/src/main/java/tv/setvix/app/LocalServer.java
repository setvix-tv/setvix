package tv.setvix.app;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Локальный «сервер» внутри приложения:
 *  https://setvix.local/index.html  -> плеер из assets
 *  https://setvix.local/proxy?url=  -> загрузка любого адреса без ограничений CORS и http/https
 */
final class LocalServer {
    static final String HOST = "setvix.local";
    static final String BASE = "https://" + HOST + "/";
    private static final String UA = "Mozilla/5.0 (Linux; Android 10; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36 SetvixTV/1.0";

    private LocalServer() {}

    static WebResourceResponse handle(Context ctx, WebResourceRequest req) {
        Uri uri = req.getUrl();
        if (!HOST.equals(uri.getHost())) return null; // остальное идёт в сеть как обычно
        String path = uri.getPath() == null ? "/" : uri.getPath();
        try {
            if (path.equals("/") || path.equals("/index.html")) {
                return response(200, "OK", "text/html", "utf-8", new ByteArrayInputStream(loadPlayer(ctx)), null);
            }
            if (path.equals("/proxy")) {
                String target = uri.getQueryParameter("url");
                if (target == null || !(target.startsWith("http://") || target.startsWith("https://"))) {
                    return text(400, "Bad Request", "bad url");
                }
                return proxy(target, req.getRequestHeaders());
            }
            return text(404, "Not Found", "not found");
        } catch (Exception e) {
            return text(502, "Bad Gateway", String.valueOf(e.getMessage()));
        }
    }

    private static WebResourceResponse proxy(String target, Map<String, String> reqHeaders) throws Exception {
        HttpURLConnection c = null;
        String url = target;
        for (int hop = 0; hop < 6; hop++) {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(12000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "*/*");
            if (reqHeaders != null) {
                for (Map.Entry<String, String> h : reqHeaders.entrySet()) {
                    if ("range".equalsIgnoreCase(h.getKey())) c.setRequestProperty("Range", h.getValue());
                }
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) return text(502, "Bad Gateway", "redirect without location");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            break;
        }
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) return text(502, "Bad Gateway", "too many redirects");

        String ct = c.getContentType();
        String mime = "application/octet-stream", enc = null;
        if (ct != null) {
            String[] parts = ct.split(";");
            mime = parts[0].trim();
            for (String p : parts) {
                String t = p.trim().toLowerCase();
                if (t.startsWith("charset=")) enc = t.substring(8);
            }
        }
        InputStream body = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (body == null) body = new ByteArrayInputStream(new byte[0]);
        String reason = c.getResponseMessage();
        if (reason == null || reason.trim().isEmpty()) reason = code < 400 ? "OK" : "Error";
        Map<String, String> extra = new HashMap<>();
        String cr = c.getHeaderField("Content-Range");
        if (cr != null) extra.put("Content-Range", cr);
        return response(code, reason, mime, enc, body, extra);
    }

    private static WebResourceResponse text(int code, String reason, String msg) {
        return response(code, reason, "text/plain", "utf-8",
            new ByteArrayInputStream(msg.getBytes(StandardCharsets.UTF_8)), null);
    }

    private static WebResourceResponse response(int code, String reason, String mime, String enc, InputStream in, Map<String, String> extra) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        if (extra != null) h.putAll(extra);
        return new WebResourceResponse(mime, enc, code, reason, h, in);
    }

    /**
     * Плеер берётся с сайта (там всегда свежая версия). Удачная загрузка сохраняется на приставке,
     * поэтому без интернета запускается последняя сохранённая копия, а при первом запуске — встроенная.
     */
    static byte[] loadPlayer(Context ctx) {
        File saved = new File(ctx.getFilesDir(), "player.html");
        try {
            String site = siteUrl(ctx);
            if (site != null) {
                HttpURLConnection c = (HttpURLConnection) new URL(site + "index.html?v=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(8000);
                c.setUseCaches(false);
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("User-Agent", UA);
                if (c.getResponseCode() == 200) {
                    byte[] data = readAll(c.getInputStream());
                    String head = new String(data, 0, Math.min(data.length, 4000), StandardCharsets.UTF_8);
                    if (head.contains("Setvix")) {
                        try (FileOutputStream out = new FileOutputStream(saved)) { out.write(data); }
                        return data;
                    }
                }
            }
        } catch (Exception ignored) { }
        try {
            if (saved.exists()) return readAll(new FileInputStream(saved));
            return readAll(ctx.getAssets().open("index.html"));
        } catch (Exception e) {
            return "<h1>Setvix: player not found</h1>".getBytes(StandardCharsets.UTF_8);
        }
    }

    private static String siteUrl(Context ctx) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(ctx.getAssets().open("site.txt"), StandardCharsets.UTF_8))) {
            String s = r.readLine();
            if (s == null) return null;
            s = s.trim();
            if (!s.startsWith("http")) return null;
            return s.endsWith("/") ? s : s + "/";
        } catch (Exception e) { return null; }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try (InputStream src = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = src.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }
}
