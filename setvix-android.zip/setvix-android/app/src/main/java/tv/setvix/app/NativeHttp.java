package tv.setvix.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** POST-запросы для фильмотеки (VPortal): без ограничений браузера, ответ приходит событием "http". */
final class NativeHttp {
    private NativeHttp() {}

    static void post(final MainActivity act, final String id, final String url, final String body) {
        new Thread(() -> {
            int code = 0;
            String text;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(25000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Accept", "application/json, */*");
                c.setRequestProperty("User-Agent", LocalServer.UA);
                try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                if (in != null) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0 && bo.size() < 4_000_000) bo.write(buf, 0, n);
                    in.close();
                }
                text = bo.toString("UTF-8");
            } catch (Exception e) {
                text = "ERROR: " + e.getMessage();
            }
            final String json = "{\"id\":" + MainActivity.q(id) + ",\"status\":" + code + ",\"body\":" + MainActivity.jsonString(text) + "}";
            act.runOnUiThread(() -> act.sendEvent("http", json));
        }).start();
    }
}
