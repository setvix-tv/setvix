package tv.setvix.app;

import android.view.Gravity;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Нативное воспроизведение (как в TiviMate): HLS и прямые потоки MPEG-TS, любые звуковые дорожки. */
final class NativePlayer implements Player.Listener {
    private static final String UA = LocalServer.UA;

    private final MainActivity act;
    private final FrameLayout root;
    private final SurfaceView surface;
    private final ExoPlayer player;
    private final DefaultHttpDataSource.Factory http;
    private final DefaultExtractorsFactory extractors;
    private final DefaultLoadErrorHandlingPolicy retries = new DefaultLoadErrorHandlingPolicy(8);

    private String url;
    private boolean asHls;
    private boolean triedOther;
    private String resize = "fit";
    private int vw, vh;
    private float par = 1f;
    private int rx, ry, rw, rh; // область видео на экране (для телефона); 0 = весь экран

    volatile String audioJson = "[]";
    private final List<Tracks.Group> audioGroups = new ArrayList<>();
    private final List<int[]> audioIndex = new ArrayList<>();

    NativePlayer(MainActivity act, FrameLayout root, SurfaceView surface) {
        this.act = act;
        this.root = root;
        this.surface = surface;
        http = new DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(20000);
        extractors = new DefaultExtractorsFactory()
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES);
        // Звук Dolby (AC-3/E-AC-3) и другие форматы, которые приставка сама не умеет, декодирует FFmpeg
        DefaultRenderersFactory rf = new DefaultRenderersFactory(act)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true);
        // Буфер для медленного интернета: копим запас и не начинаем, пока нет хотя бы 2.5 с видео
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 40000, 2500, 5000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build();
        player = new ExoPlayer.Builder(act, rf).setLoadControl(lc).build();
        player.setAudioAttributes(AudioAttributes.DEFAULT, true);
        player.setVideoSurfaceView(surface);
        player.addListener(this);
        ticker.postDelayed(tick, 5000);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot) v.post(this::layoutSurface);
        });
    }

    void play(String u) {
        url = u;
        triedOther = false;
        asHls = u.toLowerCase(Locale.ROOT).contains("m3u8");
        surface.setVisibility(View.VISIBLE);
        start();
    }

    private void start() {
        MediaItem.Builder ib = new MediaItem.Builder().setUri(url)
            .setLiveConfiguration(new MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(15000).setMinPlaybackSpeed(0.97f).setMaxPlaybackSpeed(1.03f).build());
        if (asHls) ib.setMimeType(MimeTypes.APPLICATION_M3U8);
        MediaItem item = ib.build();
        MediaSource src = asHls
            ? new HlsMediaSource.Factory(http).setAllowChunklessPreparation(true).setLoadErrorHandlingPolicy(retries).createMediaSource(item)
            : new ProgressiveMediaSource.Factory(http, extractors).setLoadErrorHandlingPolicy(retries).createMediaSource(item);
        player.setMediaSource(src);
        player.prepare();
        player.setPlayWhenReady(true);
    }

    /* Фильмы: перемотка и позиция просмотра (чтобы продолжить с того же места) */
    private final android.os.Handler ticker = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player.isPlaying() && !player.isCurrentMediaItemLive()) {
                long d = player.getDuration();
                act.sendEvent("pos", "{\"p\":" + player.getCurrentPosition() + ",\"d\":" + (d > 0 ? d : 0) + "}");
            }
            ticker.postDelayed(this, 5000);
        }
    };

    void seekTo(long ms) { player.seekTo(Math.max(0, ms)); }

    void seekBy(long ms) {
        long p = player.getCurrentPosition() + ms, d = player.getDuration();
        if (d > 0) p = Math.min(p, d - 1000);
        player.seekTo(Math.max(0, p));
        long dd = player.getDuration();
        act.sendEvent("pos", "{\"p\":" + Math.max(0, p) + ",\"d\":" + (dd > 0 ? dd : 0) + "}");
    }

    void stop() {
        player.stop();
        player.clearMediaItems();
        surface.setVisibility(View.GONE);
        audioJson = "[]";
    }

    void pause() { player.setPlayWhenReady(false); }

    void resume() { if (url != null && surface.getVisibility() == View.VISIBLE) player.setPlayWhenReady(true); }

    void release() { ticker.removeCallbacksAndMessages(null); player.release(); }

    void setResize(String mode) {
        resize = mode == null ? "fit" : mode;
        layoutSurface();
    }

    /** Размер картинки: fit — целиком, fill — растянуть, cover — увеличить без искажений, zoom — ещё крупнее. */
    void setRect(int x, int y, int w, int h) {
        rx = x; ry = y; rw = w; rh = h;
        layoutSurface();
    }

    private void layoutSurface() {
        int W = root.getWidth(), H = root.getHeight();
        if (W == 0 || H == 0) return;
        int ox = 0, oy = 0;
        if (rw > 0 && rh > 0) { ox = rx; oy = ry; W = Math.min(rw, W); H = Math.min(rh, H); }
        int w = W, h = H;
        if (vw > 0 && vh > 0 && !"fill".equals(resize)) {
            float va = vw * par / (float) vh, sa = W / (float) H;
            if ("zoom".equals(resize)) { w = Math.round(W * 1.2f); h = Math.round(H * 1.2f); }
            else if ("cover".equals(resize)) {
                if (va > sa) { h = H; w = Math.round(H * va); } else { w = W; h = Math.round(W / va); }
            } else {
                if (va > sa) { w = W; h = Math.round(W / va); } else { h = H; w = Math.round(H * va); }
            }
        } else if ("zoom".equals(resize)) { w = Math.round(W * 1.2f); h = Math.round(H * 1.2f); }
        FrameLayout.LayoutParams lp;
        if (rw > 0 && rh > 0) {
            lp = new FrameLayout.LayoutParams(w, h, Gravity.TOP | Gravity.LEFT);
            lp.leftMargin = ox + (W - w) / 2;
            lp.topMargin = oy + (H - h) / 2;
        } else {
            lp = new FrameLayout.LayoutParams(w, h, Gravity.CENTER);
        }
        surface.setLayoutParams(lp);
    }

    void selectAudio(int n) {
        if (n < 0 || n >= audioIndex.size()) return;
        int[] gi = audioIndex.get(n);
        Tracks.Group g = audioGroups.get(gi[0]);
        player.setTrackSelectionParameters(
            player.getTrackSelectionParameters().buildUpon()
                .setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), gi[1]))
                .build());
    }

    @Override
    public void onPlaybackStateChanged(int state) {
        if (state == Player.STATE_BUFFERING) act.sendEvent("buffering", null);
        else if (state == Player.STATE_ENDED) act.sendEvent("ended", null);
    }

    @Override
    public void onIsPlayingChanged(boolean isPlaying) {
        if (isPlaying) act.sendEvent("playing", null);
    }

    @Override
    public void onPlayerError(PlaybackException e) {
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition();
            player.prepare();
            return;
        }
        boolean parsing = e.errorCode >= 3000 && e.errorCode < 4000;
        if (!triedOther && parsing && url != null) {
            triedOther = true;
            asHls = !asHls;
            start();
            return;
        }
        act.sendEvent("error", "{\"code\":" + e.errorCode + ",\"name\":" + MainActivity.q(e.getErrorCodeName()) + "}");
    }

    @Override
    public void onVideoSizeChanged(VideoSize size) {
        vw = size.width;
        vh = size.height;
        par = size.pixelWidthHeightRatio > 0 ? size.pixelWidthHeightRatio : 1f;
        layoutSurface();
        act.sendEvent("size", "{\"w\":" + vw + ",\"h\":" + vh + ",\"r\":" + par + "}");
    }

    @Override
    public void onTracksChanged(Tracks tracks) {
        audioGroups.clear();
        audioIndex.clear();
        StringBuilder b = new StringBuilder("[");
        List<Tracks.Group> groups = tracks.getGroups();
        for (int gi = 0; gi < groups.size(); gi++) {
            Tracks.Group g = groups.get(gi);
            if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
            int groupPos = audioGroups.size();
            audioGroups.add(g);
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                Format f = g.getTrackFormat(i);
                if (audioIndex.size() > 0) b.append(',');
                b.append("{\"lang\":").append(MainActivity.q(f.language))
                 .append(",\"label\":").append(MainActivity.q(f.label))
                 .append(",\"codec\":").append(MainActivity.q(f.sampleMimeType))
                 .append(",\"ch\":").append(f.channelCount)
                 .append(",\"sel\":").append(g.isTrackSelected(i))
                 .append('}');
                audioIndex.add(new int[] { groupPos, i });
            }
        }
        b.append(']');
        audioJson = b.toString();
        act.sendEvent("tracks", audioJson);
    }
}
