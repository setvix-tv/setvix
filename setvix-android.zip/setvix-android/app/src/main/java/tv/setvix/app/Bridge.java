package tv.setvix.app;

import android.content.pm.PackageInfo;
import android.webkit.JavascriptInterface;

/** Команды, которые интерфейс отправляет приложению. Вызываются из фонового потока WebView. */
final class Bridge {
    private final MainActivity act;
    private final NativePlayer player;

    Bridge(MainActivity act, NativePlayer player) {
        this.act = act;
        this.player = player;
    }

    @JavascriptInterface
    public int versionCode() {
        try {
            PackageInfo pi = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
            return pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    @JavascriptInterface
    public void play(final String url) {
        act.runOnUiThread(() -> player.play(url));
    }

    @JavascriptInterface
    public void stop() {
        act.runOnUiThread(player::stop);
    }

    @JavascriptInterface
    public void pause() {
        act.runOnUiThread(player::pause);
    }

    @JavascriptInterface
    public void resume() {
        act.runOnUiThread(player::resume);
    }

    @JavascriptInterface
    public void setResize(final String mode) {
        act.runOnUiThread(() -> player.setResize(mode));
    }

    @JavascriptInterface
    public void setVideoRect(final int x, final int y, final int w, final int h) {
        act.runOnUiThread(() -> player.setRect(x, y, w, h));
    }

    @JavascriptInterface
    public String audioTracks() {
        return player.audioJson;
    }

    @JavascriptInterface
    public void selectAudio(final int n) {
        act.runOnUiThread(() -> player.selectAudio(n));
    }

    @JavascriptInterface
    public void httpPost(final String id, final String url, final String body) {
        NativeHttp.post(act, id, url, body);
    }

    @JavascriptInterface
    public void seekTo(final long ms) {
        act.runOnUiThread(() -> player.seekTo(ms));
    }

    @JavascriptInterface
    public void seekBy(final long ms) {
        act.runOnUiThread(() -> player.seekBy(ms));
    }

    @JavascriptInterface
    public void installUpdate(final String url) {
        Updater.install(act, url);
    }
}
